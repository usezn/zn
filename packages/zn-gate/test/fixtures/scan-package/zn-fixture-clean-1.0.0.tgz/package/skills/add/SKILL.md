---
name: add
description: Adds two numbers when the user asks.
---

Add the two numbers and report the sum.

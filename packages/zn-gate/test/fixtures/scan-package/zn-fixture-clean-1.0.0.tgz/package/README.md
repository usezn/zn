# Fictional example server

A test fixture. It adds two numbers.
